//
//  AppDelegate.h
//  hisiconnect
//
//  Created by hi1311 on 2017/4/22.
//  Copyright © 2017年 com.huawei.hisiconnect. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

