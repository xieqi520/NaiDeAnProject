//
//  webViewController.h
//  hisiconnect
//
//  Created by hi1311 on 2017/11/21.
//  Copyright © 2017年 com.huawei.hisiconnect. All rights reserved.
//

/*测试代码，用于ios11版本的中国区手机，程序运行时无法弹出对话框 允许"WLAN与蜂窝移动网”权限，导致发送报文失败，错误原因码-1*/

#ifndef webViewController_h
#define webViewController_h

#import <UIKit/UIKit.h>

@interface webViewController : UIViewController

@end

#endif /* webViewController_h */
