//
//  ViewController.h
//  VideoDemo
//
//  Created by zhaogenghuai on 2018/12/24.
//  Copyright © 2018年 zhaogenghuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic,strong) IBOutlet UILabel *labelStatus;
@property (nonatomic,strong) IBOutlet UILabel *labelTest;
@end

